package com.traineeatjava.ltiday7;

import java.io.FileOutputStream;
import java.io.*;

public class SerializationExample {
	private static void serialize() throws Exception{
		FileOutputStream f = new FileOutputStream("emp.txt");
		ObjectOutputStream os = new ObjectOutputStream(f);
		
		Employee e = new Employee();
		e.setEmpNo(1001);
		e.setName("Sumeet");
		e.setSalary(400000);
		
		os.writeObject(e); //Saving the state of the object - Serialization
		
		os.close();
		f.close();
		
	}
	
	public static void deserialize() throws Exception{
		FileInputStream f = new FileInputStream("emp.txt");
		ObjectInputStream os = new ObjectInputStream(f);
		
		Employee e = (Employee) os.readObject();
		
		System.out.println(e.getEmpNo());
		System.out.println(e.getName());
		System.out.println(e.getSalary());
		
		os.close();
		f.close();
	}
	
	public static void main(String[] args) throws Exception{
		serialize();
		deserialize();
	}
}
