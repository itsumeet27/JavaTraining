package com.traineeatjava.ltiday5;

public class AccountException extends Exception {
	
	public AccountException(String msg) {
		super (msg);
	}

}
