package com.traineeatjava.ltiday5;

public class BankAccount {
	
	private int acno;
	private String name;
	private double balance;
	
	public BankAccount(int acno, String name, double balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	
	public double withdraw(double amount) throws AccountException {
		if (amount > balance) {
			AccountException e = new AccountException("Insufficient Balance!");
			throw e;
		}
		else {
			balance -= amount;
			return balance;
		}
	}
	
	public static void main(String[] args) {
		BankAccount bankacc = new BankAccount(1001, "Angela",0);
		try {
			double balance = bankacc.withdraw(500);
			System.out.println("Balance left: " + balance);
		}
		catch(AccountException e) {
//			System.out.println(e.getMessage());
			e.printStackTrace(); //Used for developer understanding and not for enduser
		}
	}
	
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
}
