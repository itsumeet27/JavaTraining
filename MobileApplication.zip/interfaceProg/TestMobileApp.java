package com.traineeatjava.lti.interfaceProg;
/**
 * 
 * @author GoogleInc.
 *
 */
public class TestMobileApp {
	public static void main(String[] args) {
		MyMobileApplication1 app1 = new MyMobileApplication1();
		MyMobileApplication2 app2 = new MyMobileApplication2();
		
		Launcher launcher = new Launcher();
		launcher.launch(app1);
		launcher.launch(app2);
		
		System.out.println(launcher.runningAppCount());
		
		launcher.closeAllApps();
	}
}
