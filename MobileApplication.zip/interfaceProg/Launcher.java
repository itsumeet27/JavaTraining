package com.traineeatjava.lti.interfaceProg;
/**
 * 
 * @author GoogleInc.
 *
 */
public class Launcher{
	
	private TaskManager taskManager;
	
	public Launcher() {
		taskManager = new TaskManager();
	}
	
	public void launch(MobileApplication mobileApp) {
		mobileApp.start();
		taskManager.newAppLoaded(mobileApp);
//		mobileApp.pause();
//		mobileApp.stop();
	}
	
	public int runningAppCount() {
		return taskManager.getNumberOfRunningApps();
	}
	
	public void closeAllApps() {
		taskManager.closeAllRunningApps();
	}
}
