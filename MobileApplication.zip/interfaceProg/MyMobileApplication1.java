package com.traineeatjava.lti.interfaceProg;

public class MyMobileApplication1 implements MobileApplication {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("Application started");
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		System.out.println("Application paused");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("Application stopped");
	}

}
