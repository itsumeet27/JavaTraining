package com.traineeatjava.lti.interfaceProg;
/**
 * 
 * @author GoogleInc.
 *
 */
public interface MobileApplication {

	public void start();
	public void pause();
	public void stop();
	
}
