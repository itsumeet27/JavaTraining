package com.traineeatjava.ltiday6;
import java.io.*;

public class ReadFile {
	public static void main(String[] args) {
		FileInputStream inFile = null;
		try {
			inFile = new FileInputStream("Sample.txt");
			int ch = 0;
			while(true) {
				ch = inFile.read();
				if(ch == -1) //End of file
					break;
//				System.out.print(ch); //File is read in numeric representation
				System.out.print((char)ch); //File in character representation
			}
		}catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD Corrupted");
		}
		finally {
			try {
				inFile.close();
			}catch(Exception e){
				
			}
		}
	}
}
