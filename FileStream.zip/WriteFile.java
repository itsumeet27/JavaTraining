package com.traineeatjava.ltiday6;
import java.io.*;

public class WriteFile {
	public static void main(String[] args) {
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		try {
			inFile = new FileInputStream("Sample.txt");
			outFile = new FileOutputStream("SampleWrite.txt");
			int ch = 0;
			while(true) {
				ch = inFile.read();
				if(ch == -1) //End of file
					break;
//				System.out.print(ch); //File is read in numeric representation
//				System.out.print((char)ch); //File in character representation
				outFile.write(ch);
			}
			System.out.println("File Copied");
		}catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD Corrupted");
		}
		finally {
			try {
				inFile.close();
				outFile.close();
			}catch(Exception e){
				
			}
		}
	}
}
