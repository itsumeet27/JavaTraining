package com.traineeatjava.ltiday3;

public enum LogLevel {

	INFO, WARN, ERROR;
}
