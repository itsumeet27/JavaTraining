package com.traineeatjava.ltiday3.v5;

public class LoggerFactory {
	public static Logger getLoggerInstance() {
		return new ConsoleLogger();
	}
}
