package com.traineeatjava.ltiday3.v5;
import java.util.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A simple implementation of logging in Java
 * @author 
 * 
 */
public class ConsoleLogger extends Logger {
	
	@Override
	public void log(String msg, LogLevel level) {
		
		//Defining cases for the type of messages in the log
		switch(level) {
		case INFO: 
			System.out.println("[INFO] [" + LocalDateTime.now() + "]" + " " + msg);
			break;
		case WARN:
			System.out.println("[WARNING] [" + LocalDateTime.now() + "]" + " " + msg);
			break;
		case ERROR:
			System.out.println("[ERROR] [" + LocalDateTime.now() + "]" + " " + msg);
			break;
		}
		
	}
}
