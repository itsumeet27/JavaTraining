package com.traineeatjava.ltiday3.v6;

public class TestLogger {
	public static void main(String args[]) {
		
		System.out.println("The log generated is: \n");
		//Print in the console
//		ConsoleLogger logger = new ConsoleLogger();
//		logger.log("Show Message \n");
//		logger.log("Some concern to address \n", LogLevel.WARN);
//		logger.log("Some critical situation has arised \n", LogLevel.ERROR);
//		
		//Print in the file
//		FileLogger filelogger = new FileLogger();
//		filelogger.log("Show Message \n\n");
//		filelogger.log("Some concern to address \n\n", LogLevel.WARN);
//		filelogger.log("Some critical situation has arised \n\n", LogLevel.ERROR);
		
//		Logger logger = new FileLogger();
//		logger.log("Show Message \n");
//		logger.log("Some concern to address \n", LogLevel.WARN); //Calls the overriden log method of FileLogger
//		logger.log("Some critical situation has arised \n", LogLevel.ERROR); //Calls the overriden log method of FileLogger
//		
//		Logger consoleLogger = new ConsoleLogger();
//		consoleLogger.log("Show Message \n");
//		consoleLogger.log("Some concern to address \n", LogLevel.WARN); //Calls the overriden log method of ConsoleLogger
//		consoleLogger.log("Some critical situation has arised \n", LogLevel.ERROR); //Calls the overriden log method of ConsoleLogger
		
		Logger logger = LoggerFactory.getLoggerInstance();
		logger.log("Show Message \n");
		logger.log("Some concern to address \n", LogLevel.WARN); 
		logger.log("Some critical situation has arised \n", LogLevel.ERROR); 
		
	}
}
