package com.traineeatjava.ltiday3.v6;

public enum LogLevel {

	//ENUM created with constants for type of log messages
	INFO, WARN, ERROR;
}
