package com.traineeatjava.ltiday3.v6;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A simple implementation of logging in Java
 * @author 
 * 
 */
public class FileLogger implements Logger{
	
	@Override
	public void log(String msg, LogLevel level) {
		
		//Exception Handling
		try(FileWriter fw = new FileWriter("app.log", true)){
			
			//Defining cases for the type of messages in the log
			switch(level) {
			case INFO: 
				fw.write("[INFO] [" + LocalDateTime.now() + "]" + " " + msg);
				break;
			case WARN:
				fw.write("[WARNING] [" + LocalDateTime.now() + "]" + " " + msg);
				break;
			case ERROR:
				fw.write("[ERROR] [" + LocalDateTime.now() + "]" + " " + msg);
				break;
			}
		}	
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
