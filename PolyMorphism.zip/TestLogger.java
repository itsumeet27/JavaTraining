package com.traineeatjava.ltiday3;

public class TestLogger {
	public static void main(String args[]) {
		Logger logger = new Logger();
		logger.log("Show Message");
		logger.log("Some concern to address", LogLevel.WARN);
		logger.log("Some critical situation has arised", LogLevel.ERROR);
	}
}
