package com.traineeatjava.ltiday3.v3;

public class Logger {
	public void log(String msg) {
		//System.out.println("[INFO] [" + LocalDateTime.now() + "]" + " " + msg); 
		//Reusing the code under log method below
		log(msg, LogLevel.INFO);
	}
	
	public void log(String msg, LogLevel level) {
		
	}
}
