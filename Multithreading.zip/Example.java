package com.traineeatjava.ltiday6;

public class Example {
	
	class  Task1 implements Runnable{
		
		@Override
		public void run() {
			for(int i=0;i<10000000;i++) {
				System.out.println("Task1 running");
				Thread.yield();
//				try {
//					Thread.sleep(1);
//				} 
//				catch(InterruptedException e) {
//				}
			}				
		}
	}
	
	class  Task2 implements Runnable{
		
		@Override
		public void run() {
			for(int i=0;i<10000000;i++) {
				System.out.println("Task2 running");
				Thread.yield();
			}
//			try {
//				Thread.sleep(1);
//			} 
//			catch(InterruptedException e) {
//			}
		}
	}
	
	private void launch (){
		Task1 s1=new Task1();
		Task2 d1=new Task2();
		Thread t1=new Thread(s1);
		Thread t2=new Thread(d1);
//		t1.setDaemon(true);
//		t2.setDaemon(true);
//		t1.setPriority(1);
//		t2.setPriority(10);
		t1.start();
		t2.start();
		
	}
	
	public static void main(String[] args) {
		Example e=new Example();
		e.launch();
	}

}