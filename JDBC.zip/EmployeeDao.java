package com.traineeatjava.ltiday7;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//Data Access Object
public class EmployeeDao {
	public void  add(Employee emp) throws DataAccessException, SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null; //Precompiled SQL Comments
		
		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
//
//			//Syntax below remains same for update and delete
//			pstmt = conn.prepareStatement("insert into emp2 values(?,?,?)"); //To add value in the runtime '?' is added inside values
//			
//			//Syntax for inserting data "pstmt.setString(column_no,object.method())"
//			pstmt.setString (1, emp.getName());
//			pstmt.setDouble(2, emp.getSalary());
//			pstmt.setInt(3, emp.getEmpNo());
//			pstmt.executeUpdate(); //Inserting data in table and updating table
//			
//			System.out.println("Data inserted");
		}
		catch(Exception e) {
			throw new DataAccessException ("Hello World", e);
		}

		finally {
			try {
				pstmt.close();
			}catch(Exception e){
				
			}
			try {
				conn.close();
			}
			catch(Exception e) {
				
			}
			
		}
	}
	
	public List<Employee> fetchAll() throws DataAccessException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");

			//Fetching values from the database
			pstmt = conn.prepareStatement("select * from emp2"); 
			rs = pstmt.executeQuery();
			
			List<Employee> list = new ArrayList<>();
			while(rs.next()) {
				Employee emp = new Employee();
				emp.setEmpNo(rs.getInt(3));
				emp.setName(rs.getString(1));
				emp.setSalary(rs.getDouble(2));
				
				list.add(emp);
				
			}
			return list;
		}catch(ClassNotFoundException | SQLException e){
			throw new DataAccessException("Problem while fetching details of the Employee!", e);
		}
		finally {
			try {
				rs.close();
			}catch(Exception e){
				
			}
			try {
				pstmt.close();
			}catch(Exception e){
				
			}
			try {
				conn.close();
			}catch(Exception e){
				
			}
		}
	}
}