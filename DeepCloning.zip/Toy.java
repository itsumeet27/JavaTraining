package com.traineeatjava.ltiday4;

import java.util.Arrays;

public class Toy implements Cloneable {
	
	private int count;
	private String batteryName;
	private Battery[] batteries;
	
	public Toy() {
		
	}
	
	public void addBattery(String batteryName) {
		Battery battery = new Battery(batteryName);
		batteries[count++] = battery;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException{
		Toy t = (Toy) super.clone();
		Battery[] newBatteries = new Battery[batteries.length];
		for (int i=0; i<batteries.length; i++)
			newBatteries[i] = (Battery) batteries[i].clone();
		t.setBatteries(newBatteries);
		return t;
	}
	
	public String getBatteryName() {
		return batteryName;
	}

	public void setBatteryName(String batteryName) {
		this.batteryName = batteryName;
	}

	public Battery[] getBatteries() {
		return batteries;
	}

	public void setBatteries(Battery[] batteries) {
		this.batteries = batteries;
	}

	@Override
	public String toString() {
		return "Toy [count=" + count + ", batteryName=" + batteryName + ", batteries=" + Arrays.toString(batteries) + "]";
	}

	public Toy(String batteryName, int noOfBatteries) {
		this.batteryName = batteryName;
		this.batteries = new Battery[noOfBatteries];	
	}
	
	
}
