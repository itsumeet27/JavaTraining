package com.traineeatjava.ltiday4;

public class Battery implements Cloneable {
	
	private static int sequence = 1;
	private String batteryName;
	private int batteryNumber = sequence++;
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	@Override
	public String toString() {
		return "Battery [batteryName=" + batteryName + ", batteryNumber=" + batteryNumber + "]";
	}

	public Battery(String batteryName) {
		super();
		this.batteryName = batteryName;
		this.batteryNumber = batteryNumber;
	}

	public int getBatteryNumber() {
		return batteryNumber;
	}

	public String getBatteryName() {
		return batteryName;
	}

	public void setBatteryName(String batteryName) {
		this.batteryName = batteryName;
	}

	public void setBatteryNumber(int batteryNumber) {
		this.batteryNumber = batteryNumber;
	}

}
