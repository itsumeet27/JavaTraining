package com.traineeatjava.ltiday4;

public class Test {
	public static void main(String[] args) throws CloneNotSupportedException {		
		Toy t = new Toy("RC Car", 6);
		t.addBattery("Sony");
		t.addBattery("Duracell");
		t.addBattery("Nippo");
		t.addBattery("Eveready");
		t.addBattery("Nyasa");
		t.addBattery("Samsung");
		
		Toy t2 = (Toy) t.clone();
		
		System.out.println(t);
		System.out.println(t2);
	}
}
