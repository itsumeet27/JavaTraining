package com.traineeatjava.lti.ObjectClass;

public class TestPerson {
	public static void main(String[] args) {
		Person p1 = new Person();
		Person p2 = new Person();
		p1.setName("Angela");
		p1.setAge(22);
		
		System.out.println(p1.getName() + " is " + p1.getAge() + " years old.");
		
		p2.setName("Angela");
		p2.setAge(22);
		
		//System.out.println(p1 == p2); Address of the objects is referred
		System.out.println(p1.equals(p2)); //Works when the method is Overriden
		
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());
	}
}
