package com.traineeatjava.lti;
import java.util.*;

public class Phone {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PhoneBook pb = new PhoneBook();
		
		String ans = "";
		do {
			System.out.println("Enter your details: ");
			String name = sc.next();
			String number = sc.next();
			String email = sc.next();
			String dob = sc.next();
			
			Contact c = new Contact(name, number, email, dob);
			pb.add(c);
			
			System.out.println("Do you wish to continue(y/n) ");
			ans = sc.next();
		} while(ans.equals("y"));
		
		pb.display();
		
		System.out.println("Enter a name to search: ");
		String sname = sc.next();
		Contact search = pb.searchByName(sname);
		if(search != null) {
			System.out.println(search.getName() + "\n" + search.getNumber() + "\n" + search.getEmail() + "\n" + search.getDob());
		}
		else {
			System.out.println("No match found");
		}
	}
}
