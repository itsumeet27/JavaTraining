package com.traineeatjava.lti;

public class PhoneBook {
	private int count = 0;
	private Contact[] contacts;
	
	//Default Constructor
	public PhoneBook() {
		contacts = new Contact[100];
	}
	
	//Parameterized Constructor
	public PhoneBook(int noOfEntries) {
		contacts = new Contact[noOfEntries];
	}
	
	public void add(Contact contact) {
		contacts[count++] = contact;
	}
	
	public void display() {
		System.out.println("Name \tNumber \tEmail \tDate Of Birth");
		for(int i=0;i<count;i++) {
			System.out.println(contacts[i].getName() + "\t" + contacts[i].getNumber() + "\t" + contacts[i].getEmail() + "\t" + contacts[i].getDob() + "\n");
		}		
	}
	
	public Contact searchByName(String name) {
		for(int i=0;i<count;i++) {
			if(contacts[i].getName().equals(name)) {
				System.out.println("Contact found: ");
				return contacts[i];
			}			
		}
		return null;
	}
	
	public Contact searchByNumber(String number) {
		for(int i=0;i<count;i++) {
			if(contacts[i].getNumber() == number) {
				System.out.println("Contact found: ");
				return contacts[i];
			}			
		}
		return null;
	}
	
	public void clear() {
		
	}
}
