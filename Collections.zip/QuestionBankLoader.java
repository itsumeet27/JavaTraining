package com.traineeatjava.ltiday6;

import java.util.*;

public class QuestionBankLoader {
	private QuestionBank questions;
	
	public QuestionBankLoader() {
		// TODO Auto-generated constructor stub
		questions = new QuestionBank();
	}
	
	public void loadQuestionsOnJava() {
		
		questions.addNewSubject("Java");
		 Question q = new Question();
		 q.setQuestion("What is a class?");
		 List<Option> options = new ArrayList<>();
		 Option o1= new Option("class is a template", true);
		 Option o2 = new Option("class is a classroom", false);
		 Option o3= new Option("class is a datatype", false);
		 Option o4= new Option("class is a class", false);
		 
		 options.add(o1);
		 options.add(o2);
		 options.add(o3);
		 options.add(o4);
		 
		 q.setOptions(options);
		 questions.addNewQuestion("Java", q);
		 
		 //2nd Question
		 q = new Question();
		 q.setQuestion("What is Java?");
		 options = new ArrayList<>();
		 o1= new Option("language", true);
		 o2 = new Option("bike", false);
		 o3= new Option("car", false);
		 o4= new Option("company", false);
		 
		 options.add(o1);
		 options.add(o2);
		 options.add(o3);
		 options.add(o4);
		 
		 q.setOptions(options);
		 questions.addNewQuestion("Java", q);
	}
	
	public void startExam() {
		Scanner input = new Scanner(System.in);
		int score = 0;
		
		List<Question> ques = questions.getQuestionsFor("Java");
		int i=1;
		for(Question question: ques) {
			System.out.println("Q. " + i++ + ". " + question.getQuestion());
			int x=1;
			for(Option option: question.getOptions()) {
				System.out.println(x++ + ". " + option.getOption());
			}
			System.out.println("Enter your answer (1-4): ");
			int ans = input.nextInt();
			Option selectedOption = question.getOptions().get(ans-1);
			if(selectedOption.isRightAnswer())
				score++;
		}
		System.out.println("You have scored: " + score);
		
	}
	
	public static void main(String[] args) {
		
		QuestionBankLoader qbl = new QuestionBankLoader();
		qbl.loadQuestionsOnJava();
		qbl.startExam();
	}
}	
