package com.traineeatjava.ltiday6;
import java.util.*;

public class QuestionBank {
	
	private Map<String, List<Question>> questions;
	
	public QuestionBank() {
		questions = new HashMap<>();
		
	}
	
		public void addNewSubject(String subject )  {
			questions.put(subject, new ArrayList<>());
		}
		public void addNewQuestion(String subject, Question question) {
			List<Question> ques = questions.get(subject);
			ques.add(question);
		}
		public List<Question> getQuestionsFor(String subject) {
			return questions.get(subject);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
