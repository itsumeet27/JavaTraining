package com.traineeatjava.ltiday5;
import java.util.*;

public class UserManager {
	
	private List<User> users;
	
	public UserManager() {
		// TODO Auto-generated constructor stub
		users = new ArrayList<User>();
		//Default value of an Object holds null value
		users.add(new User("itsumeet", "8286"));
		users.add(new User("addy.afriend", "9870"));
		users.add(new User("rahul", "8898"));
		users.add(new User("karan.sharma", "9029"));
	}
	
	public boolean isValidUser(String userName, String passWord) {
		for(User user : users) {
			if(user.getUserName().equals(userName) && user.getPassWord().equals(passWord))
				return true;
		}
		return false;
	}
	
	public static void main(String[] args) {
		UserManager userMan = new UserManager();
		boolean isValid = userMan.isValidUser("itsumeet", "9768");
		System.out.println(isValid);
	}
}
