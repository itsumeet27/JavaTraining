package com.traineeatjava.ltiday5;
import java.util.*;

public class UserService {
	
	private Map<String, String> users;
	
	public UserService() {
		// TODO Auto-generated constructor stub
		users = new HashMap<>();
		//Default value of an Object holds null value
		users.put("itsumeet", "8286");
		users.put("addy.afriend", "9870");
		users.put("rahul", "8898");
		users.put("karan.sharma", "9029");
	}
	
	public boolean isValidUser(String userName, String passWord) {
			if(users.containsKey(userName)) {
				String pwd = users.get(userName);
				if(pwd.equals(passWord))
					return true;
			}
			return false;
	}
	
	public static void main(String[] args) {
		UserService userMan = new UserService();
		boolean isValid = userMan.isValidUser("itsumeet", "9987");
		System.out.println(isValid);
	}
}
